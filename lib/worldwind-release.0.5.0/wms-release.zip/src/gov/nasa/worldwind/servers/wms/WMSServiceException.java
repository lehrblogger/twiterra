/* Copyright (C) 2001, 2007 United States Government as represented by
   the Administrator of the National Aeronautics and Space Administration.
   All Rights Reserved.
*/
package gov.nasa.worldwind.servers.wms;

/**
 *
 * @author brownrigg
 * @version $Id: WMSServiceException.java 3309 2007-10-16 17:25:45Z rick $
 */
public class WMSServiceException extends Exception {
    
    public WMSServiceException(String err) {
        super(err);
    }
    
}
