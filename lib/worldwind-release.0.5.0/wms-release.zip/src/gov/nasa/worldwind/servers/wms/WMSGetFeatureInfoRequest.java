/* Copyright (C) 2001, 2007 United States Government as represented by
   the Administrator of the National Aeronautics and Space Administration.
   All Rights Reserved.
*/
package gov.nasa.worldwind.servers.wms;

/**
 *
 * @author brownrigg
 * @version $Id: WMSGetFeatureInfoRequest.java 5011 2008-04-10 16:53:54Z rick $
 */
public class WMSGetFeatureInfoRequest extends WMSRequest {
    
    public WMSGetFeatureInfoRequest(WMSHttpServletRequest req) throws WMSServiceException {
        super(req);
        throw new WMSServiceException("GetFeatureInfo request not yet implemented.");
    }
    
    public boolean isValid() {
        return false;
    }
    
    public String getParseReport() {
        return "GetFeatureInfo request not implemented";
    }
}
