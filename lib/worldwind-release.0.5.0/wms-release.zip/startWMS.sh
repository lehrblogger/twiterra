java -classpath .:WMS.jar:lib/worldwind.jar:lib/jogl.jar:lib/gluegen-rt.jar:lib/activation.jar:lib/jaxb-impl.jar:lib/jsr173_1.0_api.jar:lib/jaxb-api.jar \
     -Djava.library.path=lib \
     -Xmx1024M \
     gov.nasa.worldwind.servers.wms.WMSServer
    
    